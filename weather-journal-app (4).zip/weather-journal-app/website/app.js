let d = new Date();
let newDate = d.getMonth() + "." + d.getDate() + "." + d.getFullYear();
// Api key form weather website
const apiKey = "fccbb5bd991b4febc0a463682f853d41&units=metric";

// get generate button
let genarateButton = document.getElementById("generate");
// function to get tempreature
const getTemprature = async(zipCode) => {
  const weatherApi =
    "https://api.openweathermap.org/data/2.5/weather?zip=" +
    zipCode +
    "&appid=" +
    apiKey;
  // mnake weather request
  let response = await fetch(weatherApi).then((response) => {
    return response.json();
  });
  // return temprature
  return response.main.temp;
};
// function to save data to node server
const saveData = async(newDate, temprature, feelingToday) => {
  await fetch("/add-weather-and-feeling", {
    method: "POST",
    body: JSON.stringify({
      date: newDate,
      temprature: temprature,
      feelingToday: feelingToday,
    }),
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
  });
};
//function to get data and display it
const getData = async() => {
  const savedData = await fetch("/get-weather-and-feeling").then((response) => {
    return response.json();
  });
  // display data in html
  document.getElementById("date").innerHTML = savedData.date;
  document.getElementById("temp").innerHTML = savedData.temprature;
  document.getElementById("content").innerHTML = savedData.feelingToday;
};

genarateButton.addEventListener("click", async () => {
  // get zip code from DOM
  let zipCode = document.getElementById("zip").value;
  // get feeling code from DOM

  let feelingToday = document.getElementById("feelings").value;
  // get temprature
  const temprature = getTemprature(zipCode);
  // save temprature ang feeling in application
  saveData(newDate, zipCode, feelingToday);
  // get data from server
  getData();
});
