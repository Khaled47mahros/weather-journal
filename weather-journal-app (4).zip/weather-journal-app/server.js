// projectdata object to save data
const projectData={}
// server setup
const express = require("express");
const bodyParcer = require('body-parser')
const cors = require('cors')
const app = express();
app.use(express.static('./website'));
app.use(bodyParcer.json());
app.use(cors());
const port = 8080;
// function listen to running server 
app.listen(port, () => {
  console.log("server is listening on "+port+" port");
});
// api to save request data 
app.post('/add-weather-and-feeling',(req,res)=>{
  projectData.date =req.body.date;
  projectData.temprature =req.body.temprature;
  projectData.feelingToday =req.body.feelingToday;

  res.end()
})
//api to save data 
app.get('/get-weather-and-feeling',(req,res)=>{
  res.send(projectData)
})